package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.analytics.AnalyticsTracker
import com.example.notifications.NotificationHelper
import com.example.presentation.viewmodel.AppThemeMode
import com.example.presentation.viewmodel.MainViewModel
import com.example.presentation.viewmodel.ThemeViewModel
import com.example.ui.navigation.BottomNavItem
import com.example.ui.navigation.Screen
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.ArticleDetailsScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.CategoryArticlesScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotificationSettingsScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.TecDigiTheme

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private val themeViewModel: ThemeViewModel by viewModels()

    // Holds pending article navigation from notification or deep link
    private var pendingArticleId = mutableStateOf<Long?>(null)
    private var pendingArticleUrl = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIncomingIntent(intent)

        setContent {
            val themeMode by themeViewModel.themeMode.collectAsStateWithLifecycle()
            val isDark = when (themeMode) {
                AppThemeMode.DARK -> true
                AppThemeMode.LIGHT -> false
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
            }

            TecDigiTheme(darkTheme = isDark) {
                TecDigiMainApp(
                    mainViewModel = mainViewModel,
                    themeViewModel = themeViewModel,
                    pendingArticleId = pendingArticleId.value,
                    pendingArticleUrl = pendingArticleUrl.value,
                    onHandledPendingNavigation = {
                        pendingArticleId.value = null
                        pendingArticleUrl.value = null
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return

        // Check if opened from notification extras
        val articleIdExtra = intent.getLongExtra(NotificationHelper.EXTRA_ARTICLE_ID, -1L)
        val articleUrlExtra = intent.getStringExtra(NotificationHelper.EXTRA_ARTICLE_URL)

        if (articleIdExtra > 0) {
            pendingArticleId.value = articleIdExtra
            AnalyticsTracker.logNotificationOpen(this, articleIdExtra, intent.getStringExtra(NotificationHelper.EXTRA_ARTICLE_TITLE))
        } else if (!articleUrlExtra.isNullOrBlank()) {
            pendingArticleUrl.value = articleUrlExtra
            AnalyticsTracker.logNotificationOpen(this, null, intent.getStringExtra(NotificationHelper.EXTRA_ARTICLE_TITLE))
        }

        // Check deep link URI (https://www.tecdigi.com/... or tecdigi://article/...)
        val dataUri = intent.data
        if (dataUri != null) {
            val path = dataUri.path ?: ""
            if (dataUri.scheme == "tecdigi") {
                val idFromHost = dataUri.lastPathSegment?.toLongOrNull()
                if (idFromHost != null) {
                    pendingArticleId.value = idFromHost
                }
            } else if (dataUri.host?.contains("tecdigi.com") == true && path.length > 1) {
                pendingArticleUrl.value = dataUri.toString()
            }
        }
    }
}

@Composable
fun TecDigiMainApp(
    mainViewModel: MainViewModel,
    themeViewModel: ThemeViewModel,
    pendingArticleId: Long?,
    pendingArticleUrl: String?,
    onHandledPendingNavigation: () -> Unit
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Request notification permission on Android 13+ (Tiramisu)
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* Handled */ }
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Handle deep link / notification navigation once splash has finished or immediately
    LaunchedEffect(pendingArticleId, pendingArticleUrl) {
        if (pendingArticleId != null && pendingArticleId > 0) {
            navController.navigate(Screen.ArticleDetails.createRoute(pendingArticleId))
            onHandledPendingNavigation()
        } else if (!pendingArticleUrl.isNullOrBlank()) {
            navController.navigate(Screen.ArticleDetails.createRoute(-1L, pendingArticleUrl))
            onHandledPendingNavigation()
        }
    }

    val showBottomBar = currentRoute in listOf(
        Screen.Home.route,
        Screen.Categories.route,
        Screen.Search.route,
        Screen.Favorites.route,
        Screen.Settings.route
    )

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(modifier = Modifier.testTag("main_bottom_nav")) {
                    BottomNavItem.items.forEach { item ->
                        val isSelected = currentRoute == item.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title
                                )
                            },
                            label = { Text(item.title) },
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(
                    onTimeout = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = mainViewModel,
                    onArticleClick = { articleId ->
                        navController.navigate(Screen.ArticleDetails.createRoute(articleId))
                    },
                    onSearchClick = {
                        navController.navigate(Screen.Search.route)
                    },
                    onNotificationsClick = {
                        navController.navigate(Screen.NotificationSettings.route)
                    },
                    onCategoryClick = { categoryId, categoryName ->
                        navController.navigate(Screen.CategoryArticles.createRoute(categoryId, categoryName))
                    }
                )
            }

            composable(Screen.Categories.route) {
                CategoriesScreen(
                    viewModel = mainViewModel,
                    onCategoryClick = { categoryId, categoryName ->
                        navController.navigate(Screen.CategoryArticles.createRoute(categoryId, categoryName))
                    }
                )
            }

            composable(
                route = Screen.CategoryArticles.route,
                arguments = listOf(
                    navArgument("categoryId") { type = NavType.LongType },
                    navArgument("categoryName") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val categoryId = backStackEntry.arguments?.getLong("categoryId") ?: 0L
                val categoryName = backStackEntry.arguments?.getString("categoryName") ?: "Category"
                CategoryArticlesScreen(
                    categoryId = categoryId,
                    categoryName = categoryName,
                    onArticleClick = { articleId ->
                        navController.navigate(Screen.ArticleDetails.createRoute(articleId))
                    },
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(
                route = Screen.ArticleDetails.route,
                arguments = listOf(
                    navArgument("articleId") { type = NavType.LongType },
                    navArgument("articleUrl") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                )
            ) { backStackEntry ->
                val articleId = backStackEntry.arguments?.getLong("articleId") ?: 0L
                val articleUrl = backStackEntry.arguments?.getString("articleUrl")
                ArticleDetailsScreen(
                    articleId = articleId,
                    articleUrl = articleUrl,
                    onBackClick = { navController.popBackStack() },
                    onRelatedArticleClick = { relatedId ->
                        navController.navigate(Screen.ArticleDetails.createRoute(relatedId))
                    }
                )
            }

            composable(Screen.Search.route) {
                SearchScreen(
                    onArticleClick = { articleId ->
                        navController.navigate(Screen.ArticleDetails.createRoute(articleId))
                    }
                )
            }

            composable(Screen.Favorites.route) {
                FavoritesScreen(
                    viewModel = mainViewModel,
                    onArticleClick = { articleId ->
                        navController.navigate(Screen.ArticleDetails.createRoute(articleId))
                    }
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen(
                    mainViewModel = mainViewModel,
                    themeViewModel = themeViewModel,
                    onNotificationsClick = {
                        navController.navigate(Screen.NotificationSettings.route)
                    },
                    onAboutClick = {
                        navController.navigate(Screen.About.route)
                    }
                )
            }

            composable(Screen.NotificationSettings.route) {
                NotificationSettingsScreen(
                    viewModel = mainViewModel,
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(Screen.About.route) {
                AboutScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }
        }
    }
}
