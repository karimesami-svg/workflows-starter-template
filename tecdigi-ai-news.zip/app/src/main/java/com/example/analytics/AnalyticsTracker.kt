package com.example.analytics

import android.content.Context
import android.os.Bundle
import android.util.Log

object AnalyticsTracker {

    private const val TAG = "TecDigiAnalytics"

    fun logEvent(context: Context, eventName: String, params: Map<String, Any> = emptyMap()) {
        val bundle = Bundle().apply {
            params.forEach { (key, value) ->
                when (value) {
                    is String -> putString(key, value)
                    is Int -> putInt(key, value)
                    is Long -> putLong(key, value)
                    is Double -> putDouble(key, value)
                    is Boolean -> putBoolean(key, value)
                    else -> putString(key, value.toString())
                }
            }
        }
        // Log locally for debugging and prepare for Firebase Analytics
        Log.d(TAG, "Event: $eventName, Parameters: $params")
    }

    fun logArticleOpen(context: Context, articleId: Long, title: String) {
        logEvent(context, "article_open", mapOf("article_id" to articleId, "title" to title))
    }

    fun logArticleShare(context: Context, articleId: Long, title: String) {
        logEvent(context, "article_share", mapOf("article_id" to articleId, "title" to title))
    }

    fun logArticleFavorite(context: Context, articleId: Long, isFavorite: Boolean) {
        logEvent(context, "article_favorite", mapOf("article_id" to articleId, "is_favorite" to isFavorite))
    }

    fun logSearch(context: Context, query: String, resultCount: Int) {
        logEvent(context, "search", mapOf("search_term" to query, "results" to resultCount))
    }

    fun logCategoryOpen(context: Context, categoryId: Long, categoryName: String) {
        logEvent(context, "category_open", mapOf("category_id" to categoryId, "category_name" to categoryName))
    }

    fun logNotificationOpen(context: Context, articleId: Long?, title: String?) {
        logEvent(context, "notification_open", mapOf("article_id" to (articleId ?: 0), "title" to (title ?: "")))
    }
}
