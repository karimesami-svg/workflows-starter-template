package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class WpPost(
    val id: Long,
    val date: String? = null,
    val modified: String? = null,
    val slug: String? = null,
    val link: String? = null,
    val title: WpRendered? = null,
    val content: WpRendered? = null,
    val excerpt: WpRendered? = null,
    val author: Long? = null,
    val categories: List<Long>? = null,
    @Json(name = "_embedded")
    val embedded: WpEmbedded? = null
)

@JsonClass(generateAdapter = true)
data class WpRendered(
    val rendered: String? = null
)

@JsonClass(generateAdapter = true)
data class WpEmbedded(
    val author: List<WpAuthor>? = null,
    @Json(name = "wp:featuredmedia")
    val featuredMedia: List<WpFeaturedMedia>? = null,
    @Json(name = "wp:term")
    val terms: List<List<WpTerm>>? = null
)

@JsonClass(generateAdapter = true)
data class WpAuthor(
    val id: Long? = null,
    val name: String? = null,
    val url: String? = null,
    val description: String? = null
)

@JsonClass(generateAdapter = true)
data class WpFeaturedMedia(
    val id: Long? = null,
    @Json(name = "source_url")
    val sourceUrl: String? = null,
    @Json(name = "alt_text")
    val altText: String? = null
)

@JsonClass(generateAdapter = true)
data class WpTerm(
    val id: Long? = null,
    val name: String? = null,
    val slug: String? = null,
    val taxonomy: String? = null
)

@JsonClass(generateAdapter = true)
data class WpCategory(
    val id: Long,
    val count: Int? = 0,
    val description: String? = null,
    val link: String? = null,
    val name: String,
    val slug: String,
    val parent: Long? = null
)
