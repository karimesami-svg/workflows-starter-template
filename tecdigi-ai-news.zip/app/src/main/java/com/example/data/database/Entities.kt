package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "articles")
data class ArticleEntity(
    @PrimaryKey val id: Long,
    val title: String,
    val excerpt: String,
    val content: String,
    val slug: String,
    val date: String,
    val modified: String,
    val featuredImageUrl: String,
    val categoryNames: String,
    val categoryIds: String,
    val authorName: String,
    val link: String,
    val isFavorite: Boolean = false,
    val cachedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val slug: String,
    val count: Int,
    val description: String,
    val parent: Long = 0
)
