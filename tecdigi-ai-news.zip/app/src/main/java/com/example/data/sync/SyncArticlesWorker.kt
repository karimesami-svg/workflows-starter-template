package com.example.data.sync

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.database.TecDigiDatabase
import com.example.data.repository.ArticleRepository
import java.util.concurrent.TimeUnit

class SyncArticlesWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    private val tag = "SyncArticlesWorker"

    override suspend fun doWork(): Result {
        Log.d(tag, "Starting background synchronization with TecDigi.com...")
        return try {
            val db = TecDigiDatabase.getDatabase(applicationContext)
            val repository = ArticleRepository(db.articleDao(), db.categoryDao())
            
            // Sync latest articles
            val articlesResult = repository.refreshArticles(page = 1, perPage = 20)
            // Sync categories
            val categoriesResult = repository.refreshCategories()

            if (articlesResult.isSuccess || categoriesResult.isSuccess) {
                Log.d(tag, "Sync completed successfully.")
                Result.success()
            } else {
                Log.w(tag, "Sync completed with warnings.")
                Result.retry()
            }
        } catch (e: Exception) {
            Log.e(tag, "Background sync failed: ${e.message}", e)
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "tecdigi_periodic_article_sync"

        fun schedulePeriodicSync(context: Context, intervalHours: Long = 6) {
            try {
                val constraints = Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()

                val syncRequest = PeriodicWorkRequestBuilder<SyncArticlesWorker>(
                    intervalHours, TimeUnit.HOURS,
                    15, TimeUnit.MINUTES // Flex interval
                )
                    .setConstraints(constraints)
                    .build()

                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    syncRequest
                )
                Log.d("SyncArticlesWorker", "Scheduled periodic sync every $intervalHours hours.")
            } catch (e: Throwable) {
                Log.w("SyncArticlesWorker", "WorkManager is not initialized or unavailable: ${e.message}")
            }
        }
    }
}
