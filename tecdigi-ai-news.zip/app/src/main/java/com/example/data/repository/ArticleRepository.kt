package com.example.data.repository

import android.util.Log
import com.example.data.api.NetworkClient
import com.example.data.api.WordPressApiService
import com.example.data.database.ArticleDao
import com.example.data.database.CategoryDao
import com.example.data.model.ModelMappers
import com.example.domain.model.Article
import com.example.domain.model.ArticleCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ArticleRepository(
    private val articleDao: ArticleDao,
    private val categoryDao: CategoryDao,
    private val apiService: WordPressApiService = NetworkClient.wordPressApi
) {
    private val tag = "ArticleRepository"

    val cachedArticles: Flow<List<Article>> = articleDao.getAllArticles()
        .map { entities -> entities.map { ModelMappers.entityToArticle(it) } }
        .flowOn(Dispatchers.IO)

    val favoriteArticles: Flow<List<Article>> = articleDao.getFavoriteArticles()
        .map { entities -> entities.map { ModelMappers.entityToArticle(it) } }
        .flowOn(Dispatchers.IO)

    val cachedCategories: Flow<List<ArticleCategory>> = categoryDao.getAllCategories()
        .map { entities -> entities.map { ModelMappers.entityToCategory(it) } }
        .flowOn(Dispatchers.IO)

    suspend fun refreshArticles(page: Int = 1, perPage: Int = 20): Result<List<Article>> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getPosts(perPage = perPage, page = page)
            if (response.isSuccessful && response.body() != null) {
                val posts = response.body()!!
                val entities = posts.map { ModelMappers.wpPostToEntity(it) }
                articleDao.insertPreservingFavorites(entities)
                Result.success(entities.map { ModelMappers.entityToArticle(it) })
            } else {
                val errorMsg = "HTTP error ${response.code()}: ${response.message()}"
                Log.w(tag, errorMsg)
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to refresh articles: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun fetchArticleById(id: Long): Result<Article> = withContext(Dispatchers.IO) {
        try {
            // First check local database
            val local = articleDao.getArticleByIdSync(id)
            if (local != null) {
                return@withContext Result.success(ModelMappers.entityToArticle(local))
            }

            // Fetch from API
            val response = apiService.getPostById(id)
            if (response.isSuccessful && response.body() != null) {
                val entity = ModelMappers.wpPostToEntity(response.body()!!)
                articleDao.insertPreservingFavorites(listOf(entity))
                Result.success(ModelMappers.entityToArticle(entity))
            } else {
                Result.failure(Exception("Article not found: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getArticleFlow(id: Long): Flow<Article?> {
        return articleDao.getArticleById(id).map { entity ->
            entity?.let { ModelMappers.entityToArticle(it) }
        }.flowOn(Dispatchers.IO)
    }

    suspend fun fetchPostsByCategory(categoryId: Long, page: Int = 1, perPage: Int = 20): Result<List<Article>> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getPostsByCategory(categoryId = categoryId, perPage = perPage, page = page)
            if (response.isSuccessful && response.body() != null) {
                val entities = response.body()!!.map { ModelMappers.wpPostToEntity(it) }
                articleDao.insertPreservingFavorites(entities)
                Result.success(entities.map { ModelMappers.entityToArticle(it) })
            } else {
                // Fallback to local filtering
                Result.failure(Exception("HTTP error ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getArticlesByCategoryFlow(categoryId: Long): Flow<List<Article>> {
        return articleDao.getArticlesByCategory(categoryId.toString()).map { list ->
            list.map { ModelMappers.entityToArticle(it) }
        }.flowOn(Dispatchers.IO)
    }

    suspend fun searchPosts(query: String, page: Int = 1, perPage: Int = 20): Result<List<Article>> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.searchPosts(query = query, perPage = perPage, page = page)
            if (response.isSuccessful && response.body() != null) {
                val entities = response.body()!!.map { ModelMappers.wpPostToEntity(it) }
                articleDao.insertPreservingFavorites(entities)
                Result.success(entities.map { ModelMappers.entityToArticle(it) })
            } else {
                Result.failure(Exception("Search error ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun searchLocalArticlesFlow(query: String): Flow<List<Article>> {
        return articleDao.searchArticles(query).map { list ->
            list.map { ModelMappers.entityToArticle(it) }
        }.flowOn(Dispatchers.IO)
    }

    suspend fun refreshCategories(): Result<List<ArticleCategory>> = withContext(Dispatchers.IO) {
        try {
            val response = apiService.getCategories(perPage = 100, hideEmpty = false)
            if (response.isSuccessful && response.body() != null) {
                val entities = response.body()!!.map { ModelMappers.wpCategoryToEntity(it) }
                categoryDao.insertCategories(entities)
                Result.success(entities.map { ModelMappers.entityToCategory(it) })
            } else {
                Result.failure(Exception("Categories HTTP error ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleFavorite(articleId: Long): Boolean = withContext(Dispatchers.IO) {
        val current = articleDao.isFavorite(articleId) ?: false
        val newStatus = !current
        articleDao.setFavorite(articleId, newStatus)
        newStatus
    }

    suspend fun resolveArticleByUrl(url: String): Article? = withContext(Dispatchers.IO) {
        val sanitized = url.trim().removeSuffix("/")
        val slug = sanitized.substringAfterLast("/")
        
        // Check local DB
        val local = articleDao.getArticleByLinkOrSlug(sanitized, slug)
        if (local != null) {
            return@withContext ModelMappers.entityToArticle(local)
        }

        // Search online by slug
        val searchResult = searchPosts(slug)
        searchResult.getOrNull()?.firstOrNull()
    }

    suspend fun clearCache() = withContext(Dispatchers.IO) {
        articleDao.clearNonFavorites()
    }
}
