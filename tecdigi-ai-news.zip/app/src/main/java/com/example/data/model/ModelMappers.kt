package com.example.data.model

import com.example.data.api.WpCategory
import com.example.data.api.WpPost
import com.example.data.database.ArticleEntity
import com.example.data.database.CategoryEntity
import com.example.domain.model.Article
import com.example.domain.model.ArticleCategory
import com.example.utils.HtmlUtils

object ModelMappers {

    fun wpPostToEntity(wpPost: WpPost): ArticleEntity {
        val titleClean = HtmlUtils.cleanHtml(wpPost.title?.rendered ?: "Untitled Article")
        val excerptClean = HtmlUtils.cleanHtml(wpPost.excerpt?.rendered ?: "")
        val contentRaw = wpPost.content?.rendered ?: ""

        // Extract featured image from _embedded or fallback to img tag regex
        var imageUrl = wpPost.embedded?.featuredMedia?.firstOrNull()?.sourceUrl ?: ""
        if (imageUrl.isBlank() && contentRaw.isNotBlank()) {
            val imgRegex = Regex("""<img[^>]+src=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
            imageUrl = imgRegex.find(contentRaw)?.groupValues?.getOrNull(1) ?: ""
        }

        // Extract author name
        val authorName = wpPost.embedded?.author?.firstOrNull()?.name ?: "TecDigi Team"

        // Extract category names and IDs
        val categoryTerms = wpPost.embedded?.terms?.flatten()?.filter { it.taxonomy == "category" }
        val categoryNames = if (!categoryTerms.isNullOrEmpty()) {
            categoryTerms.mapNotNull { it.name }.joinToString(", ")
        } else {
            "Technology"
        }
        val categoryIds = wpPost.categories?.joinToString(",") ?: ""

        return ArticleEntity(
            id = wpPost.id,
            title = titleClean,
            excerpt = excerptClean,
            content = contentRaw,
            slug = wpPost.slug ?: "",
            date = wpPost.date ?: "",
            modified = wpPost.modified ?: "",
            featuredImageUrl = imageUrl,
            categoryNames = categoryNames,
            categoryIds = categoryIds,
            authorName = authorName,
            link = wpPost.link ?: "https://www.tecdigi.com/",
            isFavorite = false
        )
    }

    fun entityToArticle(entity: ArticleEntity): Article {
        val categoriesList = entity.categoryNames.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val categoryIdsList = entity.categoryIds.split(",").mapNotNull { it.trim().toLongOrNull() }
        val readingTime = HtmlUtils.calculateReadingTime(entity.content)
        val formattedDate = HtmlUtils.formatWpDate(entity.date)

        return Article(
            id = entity.id,
            title = entity.title,
            excerpt = entity.excerpt,
            content = entity.content,
            slug = entity.slug,
            date = entity.date,
            formattedDate = formattedDate,
            featuredImageUrl = entity.featuredImageUrl,
            categories = if (categoriesList.isEmpty()) listOf("Technology") else categoriesList,
            categoryIds = categoryIdsList,
            author = entity.authorName,
            link = entity.link,
            readingTimeMinutes = readingTime,
            isFavorite = entity.isFavorite
        )
    }

    fun wpCategoryToEntity(wpCategory: WpCategory): CategoryEntity {
        return CategoryEntity(
            id = wpCategory.id,
            name = HtmlUtils.cleanHtml(wpCategory.name),
            slug = wpCategory.slug,
            count = wpCategory.count ?: 0,
            description = HtmlUtils.cleanHtml(wpCategory.description ?: ""),
            parent = wpCategory.parent ?: 0L
        )
    }

    fun entityToCategory(entity: CategoryEntity): ArticleCategory {
        return ArticleCategory(
            id = entity.id,
            name = entity.name,
            slug = entity.slug,
            count = entity.count,
            description = entity.description,
            parent = entity.parent
        )
    }
}
