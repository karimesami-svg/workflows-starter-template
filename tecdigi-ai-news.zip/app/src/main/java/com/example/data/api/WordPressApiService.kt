package com.example.data.api

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface WordPressApiService {

    @GET("posts")
    suspend fun getPosts(
        @Query("per_page") perPage: Int = 20,
        @Query("page") page: Int = 1,
        @Query("_embed") embed: String = "true"
    ): Response<List<WpPost>>

    @GET("posts/{id}")
    suspend fun getPostById(
        @Path("id") id: Long,
        @Query("_embed") embed: String = "true"
    ): Response<WpPost>

    @GET("posts")
    suspend fun getPostsByCategory(
        @Query("categories") categoryId: Long,
        @Query("per_page") perPage: Int = 20,
        @Query("page") page: Int = 1,
        @Query("_embed") embed: String = "true"
    ): Response<List<WpPost>>

    @GET("posts")
    suspend fun searchPosts(
        @Query("search") query: String,
        @Query("per_page") perPage: Int = 20,
        @Query("page") page: Int = 1,
        @Query("_embed") embed: String = "true"
    ): Response<List<WpPost>>

    @GET("categories")
    suspend fun getCategories(
        @Query("per_page") perPage: Int = 100,
        @Query("hide_empty") hideEmpty: Boolean = false
    ): Response<List<WpCategory>>
}
