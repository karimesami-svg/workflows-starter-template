package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ArticleDao {

    @Query("SELECT * FROM articles ORDER BY date DESC")
    fun getAllArticles(): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE id = :id LIMIT 1")
    fun getArticleById(id: Long): Flow<ArticleEntity?>

    @Query("SELECT * FROM articles WHERE id = :id LIMIT 1")
    suspend fun getArticleByIdSync(id: Long): ArticleEntity?

    @Query("SELECT * FROM articles WHERE link = :link OR slug = :slug LIMIT 1")
    suspend fun getArticleByLinkOrSlug(link: String, slug: String): ArticleEntity?

    @Query("SELECT * FROM articles WHERE categoryIds LIKE '%' || :categoryId || '%' ORDER BY date DESC")
    fun getArticlesByCategory(categoryId: String): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE title LIKE '%' || :query || '%' OR excerpt LIKE '%' || :query || '%' ORDER BY date DESC")
    fun searchArticles(query: String): Flow<List<ArticleEntity>>

    @Query("SELECT * FROM articles WHERE isFavorite = 1 ORDER BY cachedAt DESC")
    fun getFavoriteArticles(): Flow<List<ArticleEntity>>

    @Query("SELECT id FROM articles WHERE isFavorite = 1")
    suspend fun getFavoriteArticleIds(): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArticlesRaw(articles: List<ArticleEntity>)

    @Transaction
    suspend fun insertPreservingFavorites(newArticles: List<ArticleEntity>) {
        val favoriteIds = getFavoriteArticleIds().toSet()
        val prepared = newArticles.map { article ->
            if (favoriteIds.contains(article.id)) {
                article.copy(isFavorite = true)
            } else {
                article
            }
        }
        insertArticlesRaw(prepared)
    }

    @Query("UPDATE articles SET isFavorite = :isFavorite WHERE id = :articleId")
    suspend fun setFavorite(articleId: Long, isFavorite: Boolean)

    @Query("SELECT isFavorite FROM articles WHERE id = :articleId")
    suspend fun isFavorite(articleId: Long): Boolean?

    @Query("DELETE FROM articles WHERE isFavorite = 0")
    suspend fun clearNonFavorites()

    @Query("SELECT COUNT(*) FROM articles")
    suspend fun getCount(): Int
}

@Dao
interface CategoryDao {

    @Query("SELECT * FROM categories ORDER BY count DESC")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<CategoryEntity>)

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun getCount(): Int
}
