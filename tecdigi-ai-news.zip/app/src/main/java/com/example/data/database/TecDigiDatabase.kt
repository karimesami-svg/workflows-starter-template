package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ArticleEntity::class, CategoryEntity::class],
    version = 2,
    exportSchema = false
)
abstract class TecDigiDatabase : RoomDatabase() {

    abstract fun articleDao(): ArticleDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        @Volatile
        private var INSTANCE: TecDigiDatabase? = null

        fun getDatabase(context: Context): TecDigiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TecDigiDatabase::class.java,
                    "tecdigi.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
