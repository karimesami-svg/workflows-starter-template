package com.example.data.api

import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

@JsonClass(generateAdapter = true)
data class DeviceRegistrationRequest(
    val token: String,
    val platform: String = "android",
    val topics: List<String> = listOf("all")
)

@JsonClass(generateAdapter = true)
data class DeviceUnregistrationRequest(
    val token: String
)

@JsonClass(generateAdapter = true)
data class ApiResponse(
    val success: Boolean,
    val message: String? = null
)

@JsonClass(generateAdapter = true)
data class AppConfigResponse(
    val appName: String,
    val version: String,
    val supportedTopics: List<String>,
    val websiteUrl: String
)

interface BackendApiService {

    @POST("devices/register")
    suspend fun registerDevice(@Body request: DeviceRegistrationRequest): Response<ApiResponse>

    @POST("devices/unregister")
    suspend fun unregisterDevice(@Body request: DeviceUnregistrationRequest): Response<ApiResponse>

    @GET("config")
    suspend fun getConfig(): Response<AppConfigResponse>

    @GET("health")
    suspend fun getHealth(): Response<Map<String, String>>
}
