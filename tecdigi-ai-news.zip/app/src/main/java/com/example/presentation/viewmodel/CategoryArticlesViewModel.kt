package com.example.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.TecDigiDatabase
import com.example.data.repository.ArticleRepository
import com.example.domain.model.Article
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface CategoryArticlesUiState {
    object Loading : CategoryArticlesUiState
    data class Success(val articles: List<Article>) : CategoryArticlesUiState
    object Empty : CategoryArticlesUiState
    data class Error(val message: String) : CategoryArticlesUiState
}

class CategoryArticlesViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TecDigiDatabase.getDatabase(application)
    private val repository = ArticleRepository(db.articleDao(), db.categoryDao())

    private val _uiState = MutableStateFlow<CategoryArticlesUiState>(CategoryArticlesUiState.Loading)
    val uiState: StateFlow<CategoryArticlesUiState> = _uiState.asStateFlow()

    private var currentCategoryId: Long = 0

    fun loadCategory(categoryId: Long) {
        currentCategoryId = categoryId
        _uiState.value = CategoryArticlesUiState.Loading

        viewModelScope.launch {
            val result = repository.fetchPostsByCategory(categoryId)
            result.onSuccess { articles ->
                if (articles.isEmpty()) {
                    _uiState.value = CategoryArticlesUiState.Empty
                } else {
                    _uiState.value = CategoryArticlesUiState.Success(articles)
                }
            }.onFailure { err ->
                // Check local cached category articles
                repository.getArticlesByCategoryFlow(categoryId).collect { localArticles ->
                    if (localArticles.isNotEmpty()) {
                        _uiState.value = CategoryArticlesUiState.Success(localArticles)
                    } else {
                        _uiState.value = CategoryArticlesUiState.Error(err.message ?: "Failed to load category articles.")
                    }
                }
            }
        }
    }

    fun toggleFavorite(articleId: Long) {
        viewModelScope.launch {
            repository.toggleFavorite(articleId)
            val state = _uiState.value
            if (state is CategoryArticlesUiState.Success) {
                val updated = state.articles.map {
                    if (it.id == articleId) it.copy(isFavorite = !it.isFavorite) else it
                }
                _uiState.value = CategoryArticlesUiState.Success(updated)
            }
        }
    }
}
