package com.example.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.TecDigiDatabase
import com.example.data.repository.ArticleRepository
import com.example.domain.model.Article
import com.example.domain.model.ArticleCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TecDigiDatabase.getDatabase(application)
    val repository = ArticleRepository(db.articleDao(), db.categoryDao())

    val cachedArticles: StateFlow<List<Article>> = repository.cachedArticles
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val favoriteArticles: StateFlow<List<Article>> = repository.favoriteArticles
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val categories: StateFlow<List<ArticleCategory>> = repository.cachedCategories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _isOffline = MutableStateFlow(false)
    val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    init {
        refreshAll()
    }

    fun refreshAll() {
        viewModelScope.launch {
            _isRefreshing.value = true
            _errorMessage.value = null

            val articlesResult = repository.refreshArticles(page = 1, perPage = 20)
            val categoriesResult = repository.refreshCategories()

            if (articlesResult.isFailure) {
                _isOffline.value = true
                _errorMessage.value = "Unable to connect to TecDigi. Showing cached content."
            } else {
                _isOffline.value = false
                _errorMessage.value = null
            }

            _isRefreshing.value = false
        }
    }

    fun toggleFavorite(articleId: Long) {
        viewModelScope.launch {
            repository.toggleFavorite(articleId)
        }
    }

    fun clearCache() {
        viewModelScope.launch {
            repository.clearCache()
            refreshAll()
        }
    }
}
