package com.example.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.TecDigiDatabase
import com.example.data.repository.ArticleRepository
import com.example.domain.model.Article
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed interface ArticleDetailsUiState {
    object Loading : ArticleDetailsUiState
    data class Success(val article: Article, val relatedArticles: List<Article> = emptyList()) : ArticleDetailsUiState
    data class Error(val message: String) : ArticleDetailsUiState
}

class ArticleDetailsViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TecDigiDatabase.getDatabase(application)
    private val repository = ArticleRepository(db.articleDao(), db.categoryDao())

    private val _uiState = MutableStateFlow<ArticleDetailsUiState>(ArticleDetailsUiState.Loading)
    val uiState: StateFlow<ArticleDetailsUiState> = _uiState.asStateFlow()

    private var currentArticleId: Long? = null

    fun loadArticle(articleId: Long, articleUrl: String? = null) {
        currentArticleId = articleId
        _uiState.value = ArticleDetailsUiState.Loading

        viewModelScope.launch {
            // Observe local updates (e.g. favorite changes)
            if (articleId > 0) {
                repository.getArticleFlow(articleId).collectLatest { article ->
                    if (article != null) {
                        loadRelated(article)
                    } else {
                        // Fetch from remote
                        fetchFromRemote(articleId, articleUrl)
                    }
                }
            } else if (!articleUrl.isNullOrBlank()) {
                val resolved = repository.resolveArticleByUrl(articleUrl)
                if (resolved != null) {
                    loadArticle(resolved.id, articleUrl)
                } else {
                    _uiState.value = ArticleDetailsUiState.Error("Article could not be resolved from URL.")
                }
            } else {
                _uiState.value = ArticleDetailsUiState.Error("Invalid article request.")
            }
        }
    }

    private suspend fun fetchFromRemote(articleId: Long, articleUrl: String?) {
        val result = repository.fetchArticleById(articleId)
        result.onSuccess { article ->
            loadRelated(article)
        }.onFailure { err ->
            _uiState.value = ArticleDetailsUiState.Error(err.message ?: "Failed to load article.")
        }
    }

    private fun loadRelated(article: Article) {
        viewModelScope.launch {
            val categoryId = article.categoryIds.firstOrNull()
            val related = if (categoryId != null) {
                val catResult = repository.fetchPostsByCategory(categoryId, perPage = 5)
                catResult.getOrDefault(emptyList()).filter { it.id != article.id }.take(3)
            } else {
                emptyList()
            }
            _uiState.value = ArticleDetailsUiState.Success(article, related)
        }
    }

    fun toggleFavorite() {
        val state = _uiState.value
        if (state is ArticleDetailsUiState.Success) {
            viewModelScope.launch {
                val newStatus = repository.toggleFavorite(state.article.id)
                _uiState.value = state.copy(article = state.article.copy(isFavorite = newStatus))
            }
        }
    }
}
