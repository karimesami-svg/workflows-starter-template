package com.example.presentation.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.TecDigiDatabase
import com.example.data.repository.ArticleRepository
import com.example.domain.model.Article
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface SearchUiState {
    object Idle : SearchUiState
    object Loading : SearchUiState
    data class Success(val results: List<Article>) : SearchUiState
    object Empty : SearchUiState
    data class Error(val message: String) : SearchUiState
}

class SearchViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TecDigiDatabase.getDatabase(application)
    private val repository = ArticleRepository(db.articleDao(), db.categoryDao())
    private val prefs = application.getSharedPreferences("tecdigi_search_prefs", Context.MODE_PRIVATE)

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _recentSearches = MutableStateFlow<List<String>>(loadRecentSearches())
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    private var searchJob: Job? = null

    fun onQueryChange(newQuery: String) {
        _query.value = newQuery
        searchJob?.cancel()

        if (newQuery.isBlank()) {
            _uiState.value = SearchUiState.Idle
            return
        }

        searchJob = viewModelScope.launch {
            delay(400) // Debounce
            executeSearch(newQuery)
        }
    }

    fun executeSearch(searchQuery: String) {
        val trimmed = searchQuery.trim()
        if (trimmed.isBlank()) return

        _query.value = trimmed
        _uiState.value = SearchUiState.Loading

        saveRecentSearch(trimmed)

        viewModelScope.launch {
            val result = repository.searchPosts(trimmed)
            result.onSuccess { articles ->
                if (articles.isEmpty()) {
                    _uiState.value = SearchUiState.Empty
                } else {
                    _uiState.value = SearchUiState.Success(articles)
                }
            }.onFailure { err ->
                // Try searching local cache as fallback
                val localFlow = repository.searchLocalArticlesFlow(trimmed)
                localFlow.collect { localResults ->
                    if (localResults.isNotEmpty()) {
                        _uiState.value = SearchUiState.Success(localResults)
                    } else {
                        _uiState.value = SearchUiState.Error(err.message ?: "Unable to complete search.")
                    }
                }
            }
        }
    }

    private fun loadRecentSearches(): List<String> {
        val raw = prefs.getString("recent_queries", "AI,Technology,Gadgets,Software") ?: ""
        return raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(8)
    }

    private fun saveRecentSearch(query: String) {
        val current = _recentSearches.value.toMutableList()
        current.remove(query)
        current.add(0, query)
        val trimmed = current.take(8)
        _recentSearches.value = trimmed
        prefs.edit().putString("recent_queries", trimmed.joinToString(",")).apply()
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        prefs.edit().remove("recent_queries").apply()
    }

    fun toggleFavorite(articleId: Long) {
        viewModelScope.launch {
            repository.toggleFavorite(articleId)
            // If in success state, toggle favorite flag
            val state = _uiState.value
            if (state is SearchUiState.Success) {
                val updated = state.results.map {
                    if (it.id == articleId) it.copy(isFavorite = !it.isFavorite) else it
                }
                _uiState.value = SearchUiState.Success(updated)
            }
        }
    }
}
