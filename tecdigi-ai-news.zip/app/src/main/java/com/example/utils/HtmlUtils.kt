package com.example.utils

import android.os.Build
import android.text.Html
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max

object HtmlUtils {

    fun cleanHtml(rawHtml: String?): String {
        if (rawHtml.isNullOrBlank()) return ""
        val decoded = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(rawHtml, Html.FROM_HTML_MODE_LEGACY).toString()
        } else {
            @Suppress("DEPRECATION")
            Html.fromHtml(rawHtml).toString()
        }
        return decoded.trim()
    }

    fun calculateReadingTime(contentHtml: String?): Int {
        if (contentHtml.isNullOrBlank()) return 1
        val plainText = cleanHtml(contentHtml)
        val wordCount = plainText.split("\\s+".toRegex()).count { it.isNotBlank() }
        val minutes = (wordCount / 200.0).toInt()
        return max(1, minutes)
    }

    fun formatWpDate(dateString: String?): String {
        if (dateString.isNullOrBlank()) return "Recent"
        return try {
            // Typical WP format: 2026-03-24T14:30:00 or 2026-03-24T14:30:00Z
            val parser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val date: Date? = parser.parse(dateString.substringBefore("Z"))
            if (date != null) {
                val outputFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
                outputFormat.format(date)
            } else {
                dateString.substringBefore("T")
            }
        } catch (_: Exception) {
            dateString.substringBefore("T")
        }
    }
}
