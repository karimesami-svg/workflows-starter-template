package com.example

import android.app.Application
import android.util.Log
import com.example.data.sync.SyncArticlesWorker
import com.example.notifications.FirebaseHelper
import com.example.notifications.NotificationHelper
import com.example.notifications.NotificationPreferences

class TecDigiApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Log.d("TecDigiApp", "Initializing TecDigi Application...")

        // 1. Create Android Notification Channel
        NotificationHelper.createNotificationChannel(this)

        // 2. Safely initialize FirebaseApp
        FirebaseHelper.init(this)

        // 3. Setup Notification preferences and sync topic subscriptions
        val notificationPrefs = NotificationPreferences(this)
        notificationPrefs.syncTopicSubscriptions()

        // 4. Retrieve FCM registration token and register with backend (if available)
        try {
            FirebaseHelper.getMessaging()?.token?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val token = task.result
                    Log.d("TecDigiApp", "FCM Device Token: $token")
                    notificationPrefs.registerTokenWithBackend(token)
                } else {
                    Log.w("TecDigiApp", "Fetching FCM registration token failed: ${task.exception?.message}")
                }
            }
        } catch (e: Throwable) {
            Log.w("TecDigiApp", "FCM token retrieval skipped: ${e.message}")
        }

        // 5. Schedule periodic background sync using WorkManager
        SyncArticlesWorker.schedulePeriodicSync(this, intervalHours = 6)
    }
}
