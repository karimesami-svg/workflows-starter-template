package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.text.Html
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatQuote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.utils.HtmlUtils

sealed class ContentBlock {
    data class Heading(val text: String, val level: Int) : ContentBlock()
    data class Paragraph(val text: String) : ContentBlock()
    data class Blockquote(val text: String) : ContentBlock()
    data class CodeBlock(val code: String) : ContentBlock()
    data class Image(val url: String, val caption: String? = null) : ContentBlock()
    data class ListItem(val text: String, val isOrdered: Boolean, val index: Int) : ContentBlock()
}

@Composable
fun HtmlContentRenderer(
    rawHtml: String,
    modifier: Modifier = Modifier
) {
    val blocks = remember(rawHtml) { parseHtmlIntoBlocks(rawHtml) }
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current

    Column(modifier = modifier.fillMaxWidth()) {
        blocks.forEach { block ->
            when (block) {
                is ContentBlock.Heading -> {
                    Spacer(modifier = Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(if (block.level <= 2) 22.dp else 18.dp)
                                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = block.text,
                            style = when (block.level) {
                                1 -> MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, fontSize = 22.sp)
                                2 -> MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                else -> MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                            },
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                is ContentBlock.Paragraph -> {
                    if (block.text.isNotBlank()) {
                        Text(
                            text = block.text,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                lineHeight = 26.sp,
                                fontSize = 16.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                }

                is ContentBlock.Blockquote -> {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(modifier = Modifier.padding(14.dp)) {
                            Icon(
                                imageVector = Icons.Default.FormatQuote,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = block.text,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontStyle = FontStyle.Italic,
                                    lineHeight = 22.sp,
                                    fontSize = 15.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                is ContentBlock.CodeBlock -> {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF0F172A),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                    ) {
                        Text(
                            text = block.code,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = Color(0xFF38BDF8),
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                is ContentBlock.Image -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(block.url)
                            .crossfade(true)
                            .placeholder(R.drawable.ic_launcher_background)
                            .build(),
                        contentDescription = block.caption ?: "Article image",
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                    )
                    if (!block.caption.isNullOrBlank()) {
                        Text(
                            text = block.caption,
                            style = MaterialTheme.typography.labelSmall.copy(fontStyle = FontStyle.Italic),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                        )
                    } else {
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                is ContentBlock.ListItem -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp, horizontal = 8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = if (block.isOrdered) "${block.index}. " else "• ",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = block.text,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                lineHeight = 24.sp,
                                fontSize = 15.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

private fun parseHtmlIntoBlocks(rawHtml: String): List<ContentBlock> {
    val blocks = mutableListOf<ContentBlock>()
    if (rawHtml.isBlank()) return blocks

    // Split into tag segments or paragraph blocks
    val tagRegex = Regex("""<(h[1-6]|p|blockquote|pre|figure|ul|ol|img)[^>]*>([\s\S]*?)<\/\1>|<img[^>]+src=["']([^"']+)["'][^>]*>""", RegexOption.IGNORE_CASE)
    val matches = tagRegex.findAll(rawHtml)

    var hasStructuredElements = false

    for (match in matches) {
        hasStructuredElements = true
        val tag = match.groupValues[1].lowercase()
        val innerContent = match.groupValues[2]
        val standaloneImgUrl = match.groupValues[3]

        if (standaloneImgUrl.isNotBlank()) {
            blocks.add(ContentBlock.Image(standaloneImgUrl))
            continue
        }

        when {
            tag.startsWith("h") -> {
                val level = tag.substring(1).toIntOrNull() ?: 2
                val text = HtmlUtils.cleanHtml(innerContent)
                if (text.isNotBlank()) {
                    blocks.add(ContentBlock.Heading(text, level))
                }
            }

            tag == "blockquote" -> {
                val text = HtmlUtils.cleanHtml(innerContent)
                if (text.isNotBlank()) {
                    blocks.add(ContentBlock.Blockquote(text))
                }
            }

            tag == "pre" -> {
                val code = HtmlUtils.cleanHtml(innerContent)
                if (code.isNotBlank()) {
                    blocks.add(ContentBlock.CodeBlock(code))
                }
            }

            tag == "figure" -> {
                val imgRegex = Regex("""<img[^>]+src=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                val captionRegex = Regex("""<figcaption[^>]*>([\s\S]*?)<\/figcaption>""", RegexOption.IGNORE_CASE)
                val imgUrl = imgRegex.find(innerContent)?.groupValues?.getOrNull(1)
                val caption = captionRegex.find(innerContent)?.groupValues?.getOrNull(1)?.let { HtmlUtils.cleanHtml(it) }
                if (!imgUrl.isNullOrBlank()) {
                    blocks.add(ContentBlock.Image(imgUrl, caption))
                }
            }

            tag == "ul" || tag == "ol" -> {
                val isOrdered = tag == "ol"
                val liRegex = Regex("""<li[^>]*>([\s\S]*?)<\/li>""", RegexOption.IGNORE_CASE)
                val items = liRegex.findAll(innerContent)
                items.forEachIndexed { index, itemMatch ->
                    val text = HtmlUtils.cleanHtml(itemMatch.groupValues[1])
                    if (text.isNotBlank()) {
                        blocks.add(ContentBlock.ListItem(text, isOrdered, index + 1))
                    }
                }
            }

            tag == "p" -> {
                // Check if paragraph contains only an image
                val imgRegex = Regex("""<img[^>]+src=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                val imgMatch = imgRegex.find(innerContent)
                val plainText = HtmlUtils.cleanHtml(innerContent)

                if (imgMatch != null && plainText.isBlank()) {
                    val imgUrl = imgMatch.groupValues[1]
                    blocks.add(ContentBlock.Image(imgUrl))
                } else if (plainText.isNotBlank()) {
                    blocks.add(ContentBlock.Paragraph(plainText))
                }
            }
        }
    }

    if (!hasStructuredElements || blocks.isEmpty()) {
        // Fallback: simple paragraphs by newline or clean Html
        val cleaned = HtmlUtils.cleanHtml(rawHtml)
        cleaned.split("\n\n").forEach { paragraph ->
            if (paragraph.isNotBlank()) {
                blocks.add(ContentBlock.Paragraph(paragraph.trim()))
            }
        }
    }

    return blocks
}
