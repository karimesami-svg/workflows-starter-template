package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

val DarkColorScheme = darkColorScheme(
    primary = TechDarkPrimary,
    onPrimary = TechDarkOnPrimary,
    primaryContainer = TechDarkPrimaryContainer,
    onPrimaryContainer = TechDarkOnPrimaryContainer,
    secondary = TechDarkSecondary,
    onSecondary = TechDarkOnSecondary,
    secondaryContainer = TechDarkSecondaryContainer,
    onSecondaryContainer = TechDarkOnSecondaryContainer,
    tertiary = TechDarkTertiary,
    background = TechDarkBackground,
    onBackground = TechDarkOnBackground,
    surface = TechDarkSurface,
    onSurface = TechDarkOnSurface,
    surfaceVariant = TechDarkSurfaceVariant,
    onSurfaceVariant = TechDarkOnSurfaceVariant,
    outline = TechDarkOutline
)

val LightColorScheme = lightColorScheme(
    primary = TechLightPrimary,
    onPrimary = TechLightOnPrimary,
    primaryContainer = TechLightPrimaryContainer,
    onPrimaryContainer = TechLightOnPrimaryContainer,
    secondary = TechLightSecondary,
    onSecondary = TechLightOnSecondary,
    secondaryContainer = TechLightSecondaryContainer,
    onSecondaryContainer = TechLightOnSecondaryContainer,
    tertiary = TechLightTertiary,
    background = TechLightBackground,
    onBackground = TechLightOnBackground,
    surface = TechLightSurface,
    onSurface = TechLightOnSurface,
    surfaceVariant = TechLightSurfaceVariant,
    onSurfaceVariant = TechLightOnSurfaceVariant,
    outline = TechLightOutline
)

@Composable
fun TecDigiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent branding by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Keep backward compatible alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    TecDigiTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
