package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.model.Article
import com.example.domain.model.ArticleCategory
import com.example.presentation.viewmodel.MainViewModel
import com.example.ui.components.ArticleCard
import com.example.ui.components.ArticleCardSkeleton
import com.example.ui.components.HeroArticleCard
import com.example.ui.components.HeroArticleSkeleton
import com.example.ui.components.OfflineBanner
import com.example.ui.theme.TecDigiCyan

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onArticleClick: (Long) -> Unit,
    onSearchClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onCategoryClick: (Long, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val articles by viewModel.cachedArticles.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val isOffline by viewModel.isOffline.collectAsStateWithLifecycle()

    var selectedFilter by remember { mutableStateOf("All") }

    val filteredArticles = remember(articles, selectedFilter, categories) {
        if (selectedFilter == "All") {
            articles
        } else {
            val matchingCategory = categories.firstOrNull { it.name.equals(selectedFilter, ignoreCase = true) }
            val matchingNames = if (matchingCategory != null && matchingCategory.parent == 0L) {
                val subcategoryNames = categories.filter { it.parent == matchingCategory.id }.map { it.name }
                listOf(matchingCategory.name) + subcategoryNames
            } else {
                listOf(selectedFilter)
            }
            articles.filter { article ->
                article.categories.any { artCat ->
                    matchingNames.any { it.equals(artCat, ignoreCase = true) }
                }
            }
        }
    }

    val featuredArticle = remember(articles) {
        articles.firstOrNull()
    }

    val latestArticles = remember(filteredArticles, featuredArticle) {
        if (selectedFilter == "All" && featuredArticle != null) {
            filteredArticles.filter { it.id != featuredArticle.id }
        } else {
            filteredArticles
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("home_screen")
    ) {
        // App Header
        HomeTopHeader(
            onSearchClick = onSearchClick,
            onNotificationsClick = onNotificationsClick,
            onRefreshClick = { viewModel.refreshAll() },
            isRefreshing = isRefreshing
        )

        // Offline Banner
        OfflineBanner(
            isOffline = isOffline,
            onRetry = { viewModel.refreshAll() }
        )

        if (articles.isEmpty() && isRefreshing) {
            // Skeleton Loading Placeholders
            HeroArticleSkeleton()
            ArticleCardSkeleton()
            ArticleCardSkeleton()
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // Category Filter Pills
                item {
                    CategoryFilterRow(
                        categories = categories,
                        selectedFilter = selectedFilter,
                        onFilterSelected = { selectedFilter = it },
                        onExploreCategories = {
                            val first = categories.firstOrNull()
                            if (first != null) onCategoryClick(first.id, first.name)
                        }
                    )
                }

                // Hero Featured Article (Shown when "All" is active)
                if (selectedFilter == "All" && featuredArticle != null) {
                    item {
                        HeroArticleCard(
                            article = featuredArticle,
                            onClick = { onArticleClick(featuredArticle.id) }
                        )
                    }
                }

                // Section Header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (selectedFilter == "All") "Latest Articles" else selectedFilter,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                ),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Direct from TecDigi.com",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "${filteredArticles.size} articles",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Articles List
                if (latestArticles.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No articles found in this category.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    items(
                        items = latestArticles,
                        key = { it.id }
                    ) { article ->
                        ArticleCard(
                            article = article,
                            onClick = { onArticleClick(article.id) },
                            onToggleFavorite = { viewModel.toggleFavorite(article.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HomeTopHeader(
    onSearchClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onRefreshClick: () -> Unit,
    isRefreshing: Boolean
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Logo & Name
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.testTag("brand_header")
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_tecdigi_logo),
                    contentDescription = "TecDigi Logo",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "TecDigi",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Tech & AI News",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = TecDigiCyan
                        )
                    )
                }
            }

            // Actions: Refresh, Search, Notification Settings
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onRefreshClick,
                    enabled = !isRefreshing,
                    modifier = Modifier.testTag("header_refresh_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh articles",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier.testTag("header_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search articles",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier.testTag("header_notification_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notification Settings",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryFilterRow(
    categories: List<ArticleCategory>,
    selectedFilter: String,
    onFilterSelected: (String) -> Unit,
    onExploreCategories: () -> Unit
) {
    val filterOptions = remember(categories) {
        // Dynamic list: "All", followed by real categories from TecDigi.com
        val topLevel = categories.filter { it.parent == 0L }.map { it.name }
        val subcategories = categories.filter { it.parent != 0L }.map { it.name }
        listOf("All") + (topLevel + subcategories).filter { it.isNotBlank() }.distinct()
    }

    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(filterOptions) { filterName ->
            val isSelected = selectedFilter.equals(filterName, ignoreCase = true)
            FilterChip(
                selected = isSelected,
                onClick = { onFilterSelected(filterName) },
                label = {
                    Text(
                        text = filterName,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                shape = RoundedCornerShape(20.dp),
                border = null
            )
        }
    }
}
