package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.sync.SyncArticlesWorker
import com.example.presentation.viewmodel.AppThemeMode
import com.example.presentation.viewmodel.MainViewModel
import com.example.presentation.viewmodel.ThemeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    mainViewModel: MainViewModel,
    themeViewModel: ThemeViewModel,
    onNotificationsClick: () -> Unit,
    onAboutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentTheme by themeViewModel.themeMode.collectAsStateWithLifecycle()
    var showThemeDialog by remember { mutableStateOf(false) }
    var showClearCacheDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier.testTag("settings_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Section: Appearance
            SettingsSectionHeader(title = "APPEARANCE")
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                SettingsClickableRow(
                    icon = Icons.Default.Palette,
                    title = "Theme Mode",
                    subtitle = when (currentTheme) {
                        AppThemeMode.DARK -> "Dark (Deep Tech Midnight)"
                        AppThemeMode.LIGHT -> "Light (Crisp Modern)"
                        AppThemeMode.SYSTEM -> "Follow System Default"
                    },
                    onClick = { showThemeDialog = true },
                    testTag = "settings_theme_row"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section: Notifications
            SettingsSectionHeader(title = "NOTIFICATIONS")
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                SettingsClickableRow(
                    icon = Icons.Default.Notifications,
                    title = "Push Notification Preferences",
                    subtitle = "Manage topics, article alerts and push frequency",
                    onClick = onNotificationsClick,
                    testTag = "settings_notifications_row"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section: Data & Storage
            SettingsSectionHeader(title = "DATA & STORAGE")
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    SettingsClickableRow(
                        icon = Icons.Default.Sync,
                        title = "Force Sync with TecDigi.com",
                        subtitle = "Immediately pull the latest published articles",
                        onClick = {
                            mainViewModel.refreshAll()
                            SyncArticlesWorker.schedulePeriodicSync(context)
                            Toast.makeText(context, "Syncing articles from TecDigi...", Toast.LENGTH_SHORT).show()
                        },
                        testTag = "settings_sync_row"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsClickableRow(
                        icon = Icons.Default.DeleteSweep,
                        title = "Clear Article Cache",
                        subtitle = "Free up device storage (saved favorites are preserved)",
                        onClick = { showClearCacheDialog = true },
                        testTag = "settings_clear_cache_row"
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section: About & Links
            SettingsSectionHeader(title = "ABOUT & COMMUNITY")
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    SettingsClickableRow(
                        icon = Icons.Default.Info,
                        title = "About TecDigi",
                        subtitle = "Version 1.0.0 • Architecture & Mission",
                        onClick = onAboutClick,
                        testTag = "settings_about_row"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsClickableRow(
                        icon = Icons.Default.OpenInBrowser,
                        title = "Visit TecDigi.com",
                        subtitle = "Open official website in browser",
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tecdigi.com/"))
                            context.startActivity(intent)
                        },
                        testTag = "settings_visit_website_row"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsClickableRow(
                        icon = Icons.Default.OpenInBrowser,
                        title = "Contact",
                        subtitle = "Get in touch with TecDigi",
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tecdigi.com/contact/"))
                            context.startActivity(intent)
                        },
                        testTag = "settings_contact_row"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsClickableRow(
                        icon = Icons.Default.OpenInBrowser,
                        title = "Privacy Policy",
                        subtitle = "tecdigi.com/privacy-policy",
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tecdigi.com/privacy-policy/"))
                            context.startActivity(intent)
                        },
                        testTag = "settings_privacy_row"
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    SettingsClickableRow(
                        icon = Icons.Default.OpenInBrowser,
                        title = "Terms of Service",
                        subtitle = "tecdigi.com/terms-of-service",
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tecdigi.com/terms-of-service/"))
                            context.startActivity(intent)
                        },
                        testTag = "settings_terms_row"
                    )
                }
            }
        }
    }

    // Theme Selection Dialog
    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("Choose Theme Mode") },
            text = {
                Column {
                    ThemeOptionRow(
                        title = "Dark (Recommended)",
                        selected = currentTheme == AppThemeMode.DARK,
                        onSelect = {
                            themeViewModel.setThemeMode(AppThemeMode.DARK)
                            showThemeDialog = false
                        }
                    )
                    ThemeOptionRow(
                        title = "Light",
                        selected = currentTheme == AppThemeMode.LIGHT,
                        onSelect = {
                            themeViewModel.setThemeMode(AppThemeMode.LIGHT)
                            showThemeDialog = false
                        }
                    )
                    ThemeOptionRow(
                        title = "Follow System",
                        selected = currentTheme == AppThemeMode.SYSTEM,
                        onSelect = {
                            themeViewModel.setThemeMode(AppThemeMode.SYSTEM)
                            showThemeDialog = false
                        }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // Clear Cache Confirmation Dialog
    if (showClearCacheDialog) {
        AlertDialog(
            onDismissRequest = { showClearCacheDialog = false },
            title = { Text("Clear Article Cache?") },
            text = {
                Text("This will remove cached article feeds to save space. Your bookmarked favorites will NOT be deleted.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        mainViewModel.clearCache()
                        showClearCacheDialog = false
                        Toast.makeText(context, "Cache cleared successfully", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("Clear Cache", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearCacheDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp
        ),
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
    )
}

@Composable
fun SettingsClickableRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.size(38.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun ThemeOptionRow(
    title: String,
    selected: Boolean,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onSelect
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, style = MaterialTheme.typography.bodyLarge)
    }
}
