package com.example.domain.model

data class Article(
    val id: Long,
    val title: String,
    val excerpt: String,
    val content: String,
    val slug: String,
    val date: String,
    val formattedDate: String,
    val featuredImageUrl: String,
    val categories: List<String>,
    val categoryIds: List<Long>,
    val author: String,
    val link: String,
    val readingTimeMinutes: Int,
    val isFavorite: Boolean
)

data class ArticleCategory(
    val id: Long,
    val name: String,
    val slug: String,
    val count: Int,
    val description: String,
    val parent: Long = 0
)
