package com.example.notifications

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.api.DeviceRegistrationRequest
import com.example.data.api.NetworkClient
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotificationPreferences(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("tecdigi_notification_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "NotificationPrefs"
        private const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        private const val KEY_FCM_TOKEN = "fcm_token"

        const val TOPIC_ALL = "all"
    }

    var isNotificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)
        set(value) {
            prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, value).apply()
            if (!value) {
                // Unsubscribe from general topic
                try {
                    FirebaseHelper.getMessaging()?.unsubscribeFromTopic(TOPIC_ALL)
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to unsubscribe from topic $TOPIC_ALL: ${e.message}")
                }
            } else {
                syncTopicSubscriptions()
            }
        }

    fun isTopicEnabled(topic: String): Boolean {
        return prefs.getBoolean("topic_$topic", topic == TOPIC_ALL)
    }

    fun setTopicEnabled(topic: String, enabled: Boolean) {
        prefs.edit().putBoolean("topic_$topic", enabled).apply()
        if (isNotificationsEnabled) {
            try {
                if (enabled) {
                    FirebaseHelper.getMessaging()?.subscribeToTopic(topic)
                } else {
                    FirebaseHelper.getMessaging()?.unsubscribeFromTopic(topic)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Topic update failed for $topic: ${e.message}")
            }
        }
    }

    var fcmToken: String
        get() = prefs.getString(KEY_FCM_TOKEN, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_FCM_TOKEN, value).apply()
        }

    fun syncTopicSubscriptions(topics: List<String> = emptyList()) {
        if (!isNotificationsEnabled) return
        val allTopics = (listOf(TOPIC_ALL) + topics).distinct()
        allTopics.forEach { topic ->
            val enabled = isTopicEnabled(topic)
            try {
                if (enabled) {
                    FirebaseHelper.getMessaging()?.subscribeToTopic(topic)
                        ?.addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                Log.d(TAG, "Subscribed to FCM topic: $topic")
                            }
                        }
                } else {
                    FirebaseHelper.getMessaging()?.unsubscribeFromTopic(topic)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Sync topic error for $topic: ${e.message}")
            }
        }
    }

    fun registerTokenWithBackend(token: String, topics: List<String> = emptyList()) {
        this.fcmToken = token
        val allTopics = (listOf(TOPIC_ALL) + topics).distinct()
        val activeTopics = allTopics.filter { isTopicEnabled(it) }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val backendApi = NetworkClient.getBackendApi()
                val response = backendApi.registerDevice(
                    DeviceRegistrationRequest(
                        token = token,
                        platform = "android",
                        topics = activeTopics
                    )
                )
                if (response.isSuccessful) {
                    Log.d(TAG, "Device token registered with backend successfully.")
                } else {
                    Log.w(TAG, "Backend device registration responded with code: ${response.code()}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Backend device registration skipped/failed: ${e.message}")
            }
        }
    }
}
