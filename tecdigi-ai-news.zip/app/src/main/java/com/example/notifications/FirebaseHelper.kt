package com.example.notifications

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.messaging.FirebaseMessaging

object FirebaseHelper {
    private const val TAG = "FirebaseHelper"

    fun init(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val app = FirebaseApp.initializeApp(context)
                if (app == null) {
                    val options = FirebaseOptions.Builder()
                        .setApplicationId("1:100000000000:android:tecdigiapp")
                        .setApiKey("AIzaSyFallbackKeyForTecDigiPreview")
                        .setProjectId("tecdigi-app")
                        .setGcmSenderId("100000000000")
                        .build()
                    FirebaseApp.initializeApp(context, options)
                    Log.d(TAG, "Firebase initialized with fallback configuration.")
                } else {
                    Log.d(TAG, "Firebase initialized from google-services resources.")
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Could not initialize FirebaseApp: ${e.message}")
        }
    }

    fun getMessaging(): FirebaseMessaging? {
        return try {
            FirebaseMessaging.getInstance()
        } catch (e: Throwable) {
            Log.w(TAG, "FirebaseMessaging is not available: ${e.message}")
            null
        }
    }
}
