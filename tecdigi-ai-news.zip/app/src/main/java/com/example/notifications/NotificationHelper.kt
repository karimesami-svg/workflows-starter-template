package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object NotificationHelper {

    const val CHANNEL_ID_NEWS = "tecdigi_news_channel"
    const val CHANNEL_NAME = "TecDigi Latest News"
    const val CHANNEL_DESCRIPTION = "Alerts for new technology & AI articles published on TecDigi.com"

    const val EXTRA_ARTICLE_ID = "extra_article_id"
    const val EXTRA_ARTICLE_URL = "extra_article_url"
    const val EXTRA_ARTICLE_TITLE = "extra_article_title"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID_NEWS, CHANNEL_NAME, importance).apply {
                description = CHANNEL_DESCRIPTION
                enableVibration(true)
                setShowBadge(true)
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    suspend fun showArticleNotification(
        context: Context,
        articleId: Long?,
        title: String,
        body: String,
        imageUrl: String?,
        articleUrl: String?
    ) {
        createNotificationChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            articleId?.let { putExtra(EXTRA_ARTICLE_ID, it) }
            articleUrl?.let { putExtra(EXTRA_ARTICLE_URL, it) }
            putExtra(EXTRA_ARTICLE_TITLE, title)
        }

        val pendingIntentId = (articleId?.toInt() ?: title.hashCode())
        val pendingIntent = PendingIntent.getActivity(
            context,
            pendingIntentId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val bitmap: Bitmap? = if (!imageUrl.isNullOrBlank()) {
            withContext(Dispatchers.IO) {
                try {
                    val url = URL(imageUrl)
                    val connection = url.openConnection() as HttpURLConnection
                    connection.doInput = true
                    connection.connectTimeout = 5000
                    connection.readTimeout = 5000
                    connection.connect()
                    val input = connection.inputStream
                    BitmapFactory.decodeStream(input)
                } catch (_: Exception) {
                    null
                }
            }
        } else null

        val notificationBuilder = NotificationCompat.Builder(context, CHANNEL_ID_NEWS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        if (bitmap != null) {
            notificationBuilder.setStyle(
                NotificationCompat.BigPictureStyle()
                    .bigPicture(bitmap)
                    .setSummaryText(body)
            )
            notificationBuilder.setLargeIcon(bitmap)
        } else {
            notificationBuilder.setStyle(
                NotificationCompat.BigTextStyle().bigText(body)
            )
        }

        try {
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.notify(pendingIntentId, notificationBuilder.build())
        } catch (_: SecurityException) {
            // Android 13+ POST_NOTIFICATIONS permission might not be granted yet
        }
    }
}
