package com.example.notifications

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TecDigiFirebaseMessagingService : FirebaseMessagingService() {

    private val tag = "TecDigiFCMService"

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(tag, "Refreshed FCM registration token: $token")
        val prefs = NotificationPreferences(applicationContext)
        prefs.registerTokenWithBackend(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(tag, "Message received from: ${remoteMessage.from}")

        val prefs = NotificationPreferences(applicationContext)
        if (!prefs.isNotificationsEnabled) {
            Log.d(tag, "Notifications disabled by user in settings. Skipping.")
            return
        }

        // Check if message belongs to a specific topic that user disabled
        val topic = remoteMessage.data["topic"]
        if (!topic.isNullOrBlank() && !prefs.isTopicEnabled(topic)) {
            Log.d(tag, "User disabled topic: $topic. Skipping notification.")
            return
        }

        // Extract payload data
        val articleId = remoteMessage.data["article_id"]?.toLongOrNull()
            ?: remoteMessage.data["id"]?.toLongOrNull()
        val articleUrl = remoteMessage.data["article_url"]
            ?: remoteMessage.data["url"]
        val title = remoteMessage.data["title"]
            ?: remoteMessage.notification?.title
            ?: "🚀 New article on TecDigi"
        val body = remoteMessage.data["body"]
            ?: remoteMessage.notification?.body
            ?: "Read the latest technology and AI article on TecDigi.com"
        val imageUrl = remoteMessage.data["featured_image"]
            ?: remoteMessage.data["image_url"]
            ?: remoteMessage.notification?.imageUrl?.toString()

        CoroutineScope(Dispatchers.Default).launch {
            NotificationHelper.showArticleNotification(
                context = applicationContext,
                articleId = articleId,
                title = title,
                body = body,
                imageUrl = imageUrl,
                articleUrl = articleUrl
            )
        }
    }
}
