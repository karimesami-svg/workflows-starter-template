<?php
/**
 * Plugin Name: TecDigi Push Notification Webhook
 * Plugin URI: https://www.tecdigi.com/
 * Description: Sends an automated, authenticated webhook payload to the TecDigi Push Notification Backend whenever a new article is published.
 * Version: 1.0.0
 * Author: TecDigi Engineering
 * Author URI: https://www.tecdigi.com/
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// Configuration Constants (Update with your backend URL and secret key)
define('TECDIGI_BACKEND_WEBHOOK_URL', 'https://your-push-backend-domain.com/webhook/wordpress/publish');
define('TECDIGI_WEBHOOK_SECRET_KEY', 'CHANGE_THIS_SECRET_KEY');

/**
 * Hook into WordPress post status transitions to catch newly published articles
 */
add_action('transition_post_status', 'tecdigi_on_post_published', 10, 3);

function tecdigi_on_post_published($new_status, $old_status, $post) {
    // Only trigger when a post transitions to 'publish' from another status
    if ($new_status === 'publish' && $old_status !== 'publish' && $post->post_type === 'post') {
        tecdigi_dispatch_push_webhook($post->ID, $post);
    }
}

/**
 * Dispatches HTTP POST payload to the TecDigi Push Notification service
 */
function tecdigi_dispatch_push_webhook($post_id, $post) {
    // 1. Featured Image URL
    $thumbnail_id = get_post_thumbnail_id($post_id);
    $featured_image_url = $thumbnail_id ? wp_get_attachment_image_url($thumbnail_id, 'full') : '';

    // 2. Categories
    $categories = get_the_category($post_id);
    $category_name = !empty($categories) ? $categories[0]->name : 'Technology';

    // 3. Excerpt
    $excerpt = !empty($post->post_excerpt) ? $post->post_excerpt : wp_trim_words(strip_tags($post->post_content), 30);

    // 4. Author Name
    $author_name = get_the_author_meta('display_name', $post->post_author);

    // 5. Payload structure
    $body = array(
        'id'             => $post_id,
        'title'          => html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8'),
        'url'            => get_permalink($post_id),
        'excerpt'        => html_entity_decode(strip_tags($excerpt), ENT_QUOTES, 'UTF-8'),
        'featured_image' => $featured_image_url,
        'category'       => $category_name,
        'author'         => $author_name,
        'published_at'   => get_the_date('c', $post_id)
    );

    // 6. Asynchronous Non-blocking HTTP POST Request
    wp_remote_post(TECDIGI_BACKEND_WEBHOOK_URL, array(
        'method'      => 'POST',
        'timeout'     => 10,
        'redirection' => 5,
        'httpversion' => '1.1',
        'blocking'    => false, // Non-blocking so post saving in WP Admin is instantaneous
        'headers'     => array(
            'Content-Type'      => 'application/json',
            'X-TecDigi-Secret'  => TECDIGI_WEBHOOK_SECRET_KEY,
            'Authorization'     => 'Bearer ' . TECDIGI_WEBHOOK_SECRET_KEY
        ),
        'body'        => wp_json_encode($body)
    ));
}
