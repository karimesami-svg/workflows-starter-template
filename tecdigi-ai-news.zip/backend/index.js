/**
 * TecDigi Push Notification Backend Service
 * 
 * Flow:
 * WordPress (publish_post) -> Webhook -> This Service -> Firebase Admin SDK (FCM) -> TecDigi Android App
 */

const express = require('express');
const admin = require('firebase-admin');
const crypto = require('crypto');

const app = express();
app.use(express.json());

// Initialize Firebase Admin
// In production, configure GOOGLE_APPLICATION_CREDENTIALS environment variable
if (!admin.apps.length) {
    try {
        admin.initializeApp({
            credential: admin.credential.applicationDefault(),
        });
        console.log("Firebase Admin initialized successfully.");
    } catch (e) {
        console.warn("Firebase Admin credentials not configured yet. Set GOOGLE_APPLICATION_CREDENTIALS or provide serviceAccountKey.json");
    }
}

// Environment variables
const WEBHOOK_SECRET = process.env.TECDIGI_WEBHOOK_SECRET || 'CHANGE_THIS_SECRET_KEY';
const PORT = process.env.PORT || 3000;

/**
 * Health Check Endpoint
 */
app.get('/health', (req, res) => {
    res.json({
        status: 'online',
        service: 'TecDigi Push Service',
        timestamp: new Date().toISOString()
    });
});

/**
 * Device Registration Endpoint
 * Android app registers FCM token and active interest topics
 */
app.post('/api/devices/register', async (req, res) => {
    const { token, platform, topics } = req.body;

    if (!token) {
        return res.status(400).json({ error: 'Token is required' });
    }

    console.log(`Registering device (${platform || 'android'}): ${token.substring(0, 16)}...`);

    // Subscribe token to requested FCM topics
    if (Array.isArray(topics) && admin.apps.length) {
        try {
            for (const topic of topics) {
                await admin.messaging().subscribeToTopic(token, topic);
                console.log(`Subscribed ${token.substring(0, 10)}... to topic: ${topic}`);
            }
        } catch (error) {
            console.error('Error subscribing device to topics:', error);
        }
    }

    return res.status(200).json({
        success: true,
        message: 'Device registered successfully',
        registeredTopics: topics || ['all']
    });
});

/**
 * WordPress Webhook Endpoint
 * Triggered automatically when an article is published on TecDigi.com
 */
app.post('/webhook/wordpress/publish', async (req, res) => {
    // 1. Verify Authentication Secret
    const providedSecret = req.headers['x-tecdigi-secret'] || req.headers['authorization'];
    if (providedSecret !== WEBHOOK_SECRET && providedSecret !== `Bearer ${WEBHOOK_SECRET}`) {
        console.warn('Unauthorized webhook call received.');
        return res.status(401).json({ error: 'Unauthorized webhook secret token' });
    }

    const {
        id,
        title,
        excerpt,
        url,
        featured_image,
        category,
        author
    } = req.body;

    if (!id || !title) {
        return res.status(400).json({ error: 'Article ID and Title are required' });
    }

    console.log(`Received publish webhook for article #${id}: "${title}"`);

    // Determine FCM topic based on category
    let targetTopic = 'all';
    if (category) {
        targetTopic = category.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    }

    // Prepare FCM Payload
    const cleanTitle = title.replace(/<[^>]+>/g, '').trim();
    const cleanBody = (excerpt || 'New article published on TecDigi.com').replace(/<[^>]+>/g, '').trim();

    const message = {
        topic: 'all', // Primary topic subscribed by all users
        notification: {
            title: `🚀 ${cleanTitle}`,
            body: cleanBody.length > 120 ? `${cleanBody.substring(0, 117)}...` : cleanBody,
        },
        data: {
            article_id: String(id),
            article_url: String(url || 'https://www.tecdigi.com/'),
            title: cleanTitle,
            body: cleanBody,
            featured_image: featured_image || '',
            topic: targetTopic,
            author: author || 'TecDigi Team'
        },
        android: {
            priority: 'high',
            notification: {
                channelId: 'tecdigi_news_channel',
                imageUrl: featured_image || undefined,
                clickAction: 'OPEN_ARTICLE_DETAILS'
            }
        }
    };

    // Send push notification via Firebase Admin
    if (admin.apps.length) {
        try {
            const response = await admin.messaging().send(message);
            console.log(`FCM push sent successfully: ${response}`);

            // Also send to specialized category topic if different from 'all'
            if (targetTopic !== 'all') {
                const specificCategoryMsg = { ...message, topic: targetTopic };
                await admin.messaging().send(specificCategoryMsg);
                console.log(`Specialized topic push sent for topic: ${targetTopic}`);
            }

            return res.status(200).json({
                success: true,
                messageId: response,
                topic: targetTopic
            });
        } catch (error) {
            console.error('Failed to send FCM push notification:', error);
            return res.status(500).json({ error: 'FCM sending failed', details: error.message });
        }
    } else {
        console.warn('Firebase Admin not initialized. Skipping actual FCM broadcast.');
        return res.status(200).json({
            success: true,
            warning: 'FCM not initialized on server, verified payload only',
            articleId: id
        });
    }
});

app.listen(PORT, () => {
    console.log(`TecDigi Push Notification Backend running on port ${PORT}`);
});
