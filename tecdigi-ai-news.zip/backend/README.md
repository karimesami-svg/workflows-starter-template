# TecDigi Real-Time Push Notification & Webhook System

This directory contains the production-ready server-side push notification architecture connecting **TecDigi.com** (WordPress) to **Firebase Cloud Messaging (FCM)** and the **TecDigi Android application**.

---

## 1. End-to-End Architecture Flow

```
[TecDigi.com WordPress] 
      │ (publish_post hook)
      ▼
[WordPress Webhook Plugin (`tecdigi-fcm-webhook.php`)]
      │ (Authenticated HTTPS POST with Secret Token)
      ▼
[TecDigi Backend Service (`index.js`)]
      │ (Firebase Admin SDK)
      ▼
[Firebase Cloud Messaging (FCM)]
      │ (Topic: 'all', 'ai', 'technology', etc.)
      ▼
[TecDigi Android App (`TecDigiFirebaseMessagingService`)]
      │ (NotificationChannel: 'tecdigi_news_channel')
      ▼
[High-Priority BigPicture Notification on User's Device]
      │ (User taps notification)
      ▼
[MainActivity -> Deep Link Navigation to Article Details Screen]
```

---

## 2. Setting Up Firebase Cloud Messaging

1. Go to the [Firebase Console](https://console.firebase.google.com/).
2. Create a project named `TecDigi`.
3. Add an Android App with package name:
   ```
   com.tecdigi.app
   ```
4. Download `google-services.json` and place it in the `app/` folder of this project:
   ```
   app/google-services.json
   ```
5. Generate a **Service Account Private Key**:
   - Go to **Project Settings** > **Service Accounts** > **Firebase Admin SDK**.
   - Click **Generate New Private Key**.
   - Save this JSON file on your backend server as `serviceAccountKey.json`.

---

## 3. Deploying the Backend Service

### Local or Cloud Server (Node.js)

```bash
cd backend
npm install
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/serviceAccountKey.json"
export TECDIGI_WEBHOOK_SECRET="your_secure_random_token_here"
export PORT=3000
npm start
```

### Or Deploy to Google Cloud Run (Recommended)

```bash
gcloud run deploy tecdigi-push-service \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars TECDIGI_WEBHOOK_SECRET="your_secure_random_token_here"
```

---

## 4. Installing the WordPress Webhook Plugin

1. Copy `tecdigi-fcm-webhook.php` into your WordPress plugins directory:
   ```
   wp-content/plugins/tecdigi-fcm-webhook/tecdigi-fcm-webhook.php
   ```
2. Open `tecdigi-fcm-webhook.php` and set your backend URL and Secret Key:
   ```php
   define('TECDIGI_BACKEND_WEBHOOK_URL', 'https://your-push-service.run.app/webhook/wordpress/publish');
   define('TECDIGI_WEBHOOK_SECRET_KEY', 'your_secure_random_token_here');
   ```
3. Activate the plugin in **WordPress Admin > Plugins > Installed Plugins > TecDigi Push Notification Webhook**.
4. Whenever any editor publishes an article on TecDigi.com, the push notification will immediately dispatch to all Android app users!

---

## 5. Testing the Webhook Manually

You can test the webhook endpoint directly using `curl`:

```bash
curl -X POST https://your-push-service.run.app/webhook/wordpress/publish \
  -H "Content-Type: application/json" \
  -H "X-TecDigi-Secret: your_secure_random_token_here" \
  -d '{
    "id": 1234,
    "title": "OpenAI Unveils Next-Generation Model Architecture",
    "url": "https://www.tecdigi.com/ai-breakthrough",
    "excerpt": "A breakthrough deep learning paradigm enhances autonomous reasoning...",
    "featured_image": "https://www.tecdigi.com/wp-content/uploads/sample.jpg",
    "category": "Artificial Intelligence",
    "author": "TecDigi Editorial"
  }'
```

---

## 6. Deep Linking Verification

To verify that notifications and deep links open the correct article on Android:

```bash
# Custom App Scheme
adb shell am start -W -a android.intent.action.VIEW -d "tecdigi://article/1234" com.tecdigi.app

# Universal Web Link
adb shell am start -W -a android.intent.action.VIEW -d "https://www.tecdigi.com/ai-breakthrough" com.tecdigi.app
```
